

import UIKit

class custom: UITableViewCell {

    override func awakeFromNib()
    {
        super.awakeFromNib()
        
    }

    
    
    @IBOutlet weak var lblID: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblAdd: UILabel!
    
    
    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)

        
    }

}
