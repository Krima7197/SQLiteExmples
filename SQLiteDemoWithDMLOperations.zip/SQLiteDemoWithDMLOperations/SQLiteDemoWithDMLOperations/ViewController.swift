

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource
{
    var arr : [Any] = []
    
    @IBOutlet weak var txtID: UITextField!
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtAdd: UITextField!
    @IBOutlet weak var tbl: UITableView!
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        let db = DMLOperation()
        let arr = db.getdata(query: "select * from emp")
        print(arr)
        tbl.reloadData()
    }
    
    @IBAction func insert(_ sender: Any)
    {
        let query = "insert into emp(eid,ename,eadd)values(\(txtID.text!),'\(txtName.text!)','\(txtAdd.text!)')"
        let db = DMLOperation()
        let st = db.dml(query: query)
        if st == true
        {
            print("Inserted")
        }
        else
        {
            print("Failed inserting")
        }
        tbl.reloadData()
    }

    
    
    @IBAction func update(_ sender: Any)
    {
        let query = "update emp set ename='\(txtName.text!)',eadd='\(txtAdd.text!)' where eid=\(txtID.text!)"
        print(query)
        let db = DMLOperation()
        let st = db.dml(query: query)
        if st == true
        {
            print("Updated")
        }
        else
        {
            print("Failed updating")
        }
        tbl.reloadData()
    }

    
    
    @IBAction func btnDelete(_ sender: Any)
    {
        let query = "delete from emp where eid=\(txtID.text!)"
        print(query)
        let db = DMLOperation()
        let st = db.dml(query: query)
        if st == true
        {
            print("Deleted")
        }
        else
        {
            print("Failed deleting")
        }
        tbl.reloadData()
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {   let db = DMLOperation()
        let arr = db.getdata(query: "select * from emp")
        return arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! custom
        let db = DMLOperation()
        let st = db.getdata(query: "select * from emp")
        arr = st
        print(arr)
        let dic = ["eid":arr[0],"ename":arr[1],"eadd":arr[2]]
        /*cell.lblID.text = arr[0] as? String
        cell.lblName.text = arr[1] as? String
        cell.lblAdd.text = arr[2] as? String*/
        print(dic)
        cell.lblID.text = dic["eid"] as? String
        cell.lblName.text = dic["ename"] as? String
        cell.lblAdd.text = dic["eadd"] as? String
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
    {
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
}
